MAANEF PS4 DOWNLOADER V1.0 — ANDROID 15 TARGET

PENTING:
Ini adalah proyek sumber Android Studio, bukan APK terkompilasi. Build APK belum dapat dilakukan pada lingkungan ini karena Android SDK dan Gradle tidak tersedia.

FITUR:
- Target Android 15 (compileSdk/targetSdk 35).
- WebView untuk membuka halaman URL.
- DownloadListener: ketika halaman memicu unduhan standar, aplikasi mencoba meneruskan respons HTTP langsung ke FTP.
- Tombol transfer direct URL untuk link file langsung.
- Streaming HTTP ke FTP tanpa menyimpan file lengkap secara permanen di Android.
- FTP default port 2121; IP, username, password, dan folder tujuan dapat diatur.

CARA BUILD:
1. Ekstrak ZIP.
2. Buka folder proyek di Android Studio.
3. Tunggu Gradle Sync (internet diperlukan untuk mengambil dependensi).
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug: app/build/outputs/apk/debug/app-debug.apk.

PENGGUNAAN:
1. Aktifkan FTP server PS4 HEN.
2. Pastikan HP dan PS4 berada di jaringan lokal yang sama.
3. Masukkan IP PS4 dan port 2121.
4. Tempel URL halaman sumber lalu tekan OPEN URL.
5. Tekan tombol Download pada halaman di dalam aplikasi.
6. Jika WebView mengenali unduhan standar dan sumber mengizinkan permintaan GET dengan cookie, aplikasi mencoba streaming langsung ke FTP.
7. Untuk direct file URL, gunakan TRANSFER DIRECT URL.

BATASAN:
- Tidak semua situs bekerja. CAPTCHA, login kompleks, token dinamis, POST download, blob: URL, DRM, dan proteksi anti-bot dapat menghalangi transfer.
- WebView DownloadListener tidak dapat menangkap setiap jenis unduhan web.
- Cookies dari WebView dikirim sebagai header bila tersedia, tetapi beberapa situs membutuhkan header/token lain.
- Folder FTP /data/pkg/ harus writable pada server PS4. Sesuaikan jika perlu.
- FTP mentransfer file saja. Instalasi dilakukan manual melalui Package Installer di PS4.
- ZIP/RAR tidak dikonversi menjadi PKG. File yang dikirim harus sudah merupakan PKG valid agar dapat dipasang sebagai PKG.
- Gunakan hanya file yang kamu berhak unduh dan gunakan.
