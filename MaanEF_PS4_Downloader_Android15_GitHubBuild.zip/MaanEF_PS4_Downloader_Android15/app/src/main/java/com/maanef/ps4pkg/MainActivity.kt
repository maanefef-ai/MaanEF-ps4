package com.maanef.ps4pkg

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import java.io.FilterInputStream
import java.io.InputStream
import java.net.URL
import java.net.URLDecoder
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var urlBox: EditText
    private lateinit var ipBox: EditText
    private lateinit var portBox: EditText
    private lateinit var userBox: EditText
    private lateinit var passBox: EditText
    private lateinit var folderBox: EditText
    private lateinit var webView: WebView
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var openButton: Button
    private lateinit var manualButton: Button
    private var currentPageUrl: String = ""

    private val http = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 18, 16, 12)
            setBackgroundColor(0xFF0B1116.toInt())
        }

        val title = TextView(this).apply {
            text = "MaanEF  |  PS4 DOWNLOADER"
            textSize = 20f
            setTextColor(0xFF00E58A.toInt())
            gravity = android.view.Gravity.CENTER
            setPadding(0, 0, 0, 12)
        }
        root.addView(title)

        urlBox = field("Tempel URL halaman download atau direct URL")
        root.addView(urlBox, lp())
        openButton = Button(this).apply {
            text = "OPEN URL"
            setOnClickListener { openPage() }
        }
        root.addView(openButton, lp())

        val connectionTitle = TextView(this).apply {
            text = "KONEKSI FTP PS4 HEN"
            setTextColor(0xFF00E58A.toInt())
            textSize = 14f
            setPadding(0, 10, 0, 4)
        }
        root.addView(connectionTitle)

        ipBox = field("IP PS4, contoh 192.168.1.100")
        root.addView(ipBox, lp())
        portBox = field("Port FTP", "2121", android.text.InputType.TYPE_CLASS_NUMBER)
        root.addView(portBox, lp())
        userBox = field("Username FTP", "anonymous")
        root.addView(userBox, lp())
        passBox = field("Password FTP (jika diperlukan)")
        root.addView(passBox, lp())
        folderBox = field("Folder tujuan di PS4", "/data/pkg/")
        root.addView(folderBox, lp())

        manualButton = Button(this).apply {
            text = "TRANSFER DIRECT URL"
            setOnClickListener { transferDirectUrl() }
        }
        root.addView(manualButton, lp())

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }
        root.addView(progress, lp())

        status = TextView(this).apply {
            text = "Buka halaman sumber. Saat tombol download ditekan di halaman, aplikasi akan mencoba meneruskan file ke FTP."
            textSize = 12f
            setTextColor(0xFFE6EDF3.toInt())
            setPadding(0, 8, 0, 8)
        }
        root.addView(status, lp())

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = true
            settings.setSupportMultipleWindows(false)
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                    currentPageUrl = url ?: currentPageUrl
                    status.text = "Membuka halaman: $currentPageUrl"
                }
                override fun onPageFinished(view: WebView?, url: String?) {
                    currentPageUrl = url ?: currentPageUrl
                    status.text = "Halaman siap. Tekan tombol Download pada halaman. Jika unduhan dikenali, file akan dialirkan ke FTP."
                }
            }
            webChromeClient = WebChromeClient()
            setDownloadListener(DownloadListener { downloadUrl, userAgent, contentDisposition, mimeType, contentLength ->
                val cookies = CookieManager.getInstance().getCookie(downloadUrl).orEmpty()
                val referer = currentPageUrl
                val name = guessFileName(downloadUrl, contentDisposition)
                startStreaming(downloadUrl, userAgent.orEmpty(), cookies, referer, name)
            })
            setBackgroundColor(0xFF101820.toInt())
        }
        root.addView(webView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        setContentView(root)
    }

    private fun field(hintText: String, value: String = "",
                      type: Int = android.text.InputType.TYPE_CLASS_TEXT) =
        EditText(this).apply {
            hint = hintText
            setText(value)
            setSingleLine(true)
            inputType = type
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF91A0AA.toInt())
            setPadding(12, 8, 12, 8)
            setBackgroundColor(0xFF202B33.toInt())
        }

    private fun lp() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 5 }

    private fun openPage() {
        val target = urlBox.text.toString().trim()
        if (!target.startsWith("https://") && !target.startsWith("http://")) {
            status.text = "URL harus diawali http:// atau https://"
            return
        }
        currentPageUrl = target
        webView.loadUrl(target)
    }

    private fun transferDirectUrl() {
        val target = urlBox.text.toString().trim()
        if (target.startsWith("http://") || target.startsWith("https://")) {
            startStreaming(
                target,
                webView.settings.userAgentString,
                CookieManager.getInstance().getCookie(target).orEmpty(),
                currentPageUrl,
                guessFileName(target, null)
            )
        } else {
            status.text = "Masukkan URL HTTP/HTTPS terlebih dahulu."
        }
    }

    private fun guessFileName(url: String, disposition: String?): String {
        val fromDisposition = disposition?.let {
            Regex("filename\\*?=(?:UTF-8''|\\\")?([^\\\";]+)", RegexOption.IGNORE_CASE)
                .find(it)?.groupValues?.getOrNull(1)
        }
        val raw = fromDisposition ?: runCatching {
            URLDecoder.decode(URL(url).path.substringAfterLast('/'), "UTF-8")
        }.getOrDefault("download.pkg")
        val clean = raw.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._ -]"), "_")
        return clean.ifBlank { "download.pkg" }
    }

    private fun startStreaming(url: String, userAgent: String, cookies: String, referer: String, fileName: String) {
        val host = ipBox.text.toString().trim()
        val port = portBox.text.toString().trim().toIntOrNull()
        val username = userBox.text.toString().ifBlank { "anonymous" }
        val password = passBox.text.toString()
        val remoteDir = folderBox.text.toString().trim().ifBlank { "/data/pkg/" }

        if (host.isBlank() || port == null || port !in 1..65535) {
            status.text = "Isi IP PS4 dan port FTP yang benar."
            return
        }
        manualButton.isEnabled = false
        progress.progress = 0
        status.text = "Memulai streaming ke PS4..."
        lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    streamHttpToFtp(url, userAgent, cookies, referer, host, port, username, password, remoteDir, fileName)
                }
                progress.progress = 100
                status.text = "Transfer selesai: $result"
            } catch (e: Exception) {
                status.text = "Transfer gagal: ${e.message ?: "kesalahan tidak diketahui"}. Situs mungkin memakai proteksi, CAPTCHA, token, atau unduhan berbasis POST/blob."
            } finally {
                manualButton.isEnabled = true
            }
        }
    }

    private fun streamHttpToFtp(
        url: String, userAgent: String, cookies: String, referer: String,
        host: String, port: Int, username: String, password: String,
        remoteDir: String, fileName: String
    ): String {
        val requestBuilder = Request.Builder().url(url).get()
        if (userAgent.isNotBlank()) requestBuilder.header("User-Agent", userAgent)
        if (cookies.isNotBlank()) requestBuilder.header("Cookie", cookies)
        if (referer.isNotBlank()) requestBuilder.header("Referer", referer)

        http.newCall(requestBuilder.build()).execute().use { response ->
            if (!response.isSuccessful) error("Server sumber merespons HTTP ${response.code}")
            val body = response.body ?: error("Isi file kosong")
            val ftp = FTPClient()
            ftp.connectTimeout = 20000
            ftp.defaultTimeout = 20000
            ftp.dataTimeout = 60000
            ftp.setBufferSize(1024 * 1024)
            try {
                ftp.connect(host, port)
                if (!ftp.login(username, password)) error("Login FTP ditolak: ${ftp.replyString}")
                ftp.enterLocalPassiveMode()
                ftp.setFileType(FTP.BINARY_FILE_TYPE)
                if (!ftp.changeWorkingDirectory(remoteDir)) {
                    error("Folder FTP tidak dapat dibuka: $remoteDir")
                }
                val input = CountingInputStream(body.byteStream(), body.contentLength()) { sent, total ->
                    runOnUiThread {
                        if (total > 0) progress.progress = ((sent * 100L) / total).coerceIn(0, 99).toInt()
                        status.text = if (total > 0)
                            "Streaming ke PS4: ${progress.progress}%"
                        else "Streaming ke PS4: ${sent / (1024 * 1024)} MB"
                    }
                }
                val success = ftp.storeFile(fileName, input)
                input.close()
                if (!success) error("FTP menolak file: ${ftp.replyString}")
                return "$fileName → $remoteDir"
            } finally {
                runCatching { if (ftp.isConnected) { ftp.logout(); ftp.disconnect() } }
            }
        }
    }

    private class CountingInputStream(
        input: InputStream,
        private val total: Long,
        private val progressCallback: (Long, Long) -> Unit
    ) : FilterInputStream(input) {
        private var count = 0L
        override fun read(): Int {
            val r = super.read()
            if (r >= 0) { count++; progressCallback(count, total) }
            return r
        }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val n = super.read(b, off, len)
            if (n > 0) { count += n; progressCallback(count, total) }
            return n
        }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
